CREATE DATABASE homestead;
GRANT ALL PRIVILEGES ON *.* TO 'homestead'@'%';